﻿using BlogAPI.DTOs;
using BlogAPI.Entities;

namespace BlogAPI.Services
{
    public interface IPostService
    {
        Task<IEnumerable<Post>> GetAllPostsAsync();
        Task<Post?> GetPostByIdAsync(int id);
        Task<Post> CreatePostAsync(CreatePostDto dto, string userId);
        Task<bool> DeletePostAsync(int id, string userId);
        Task<PostDetailDto> GetPostDetailsByIdAsync(int id);

    }
}
